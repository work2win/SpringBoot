package simu.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import simu.model.Booking;
import simu.repository.BookingRepository;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class BookingController {
	
	@Autowired
	BookingRepository repository;
 
	@GetMapping("/bookings")
	public List<Booking> getAllBookings() {
		System.out.println("Get all Bookings...");
 
		List<Booking> bookings = new ArrayList<>();
		repository.findAll().forEach(bookings::add);
 
		return bookings;
	}
 
	@PostMapping(value = "/bookings/create")
	public Booking postBooking(@RequestBody Booking booking) {
 
		Booking _booking = repository.save(new Booking(booking.getName(), booking.getEmail(), booking.getAddress(), booking.getCost()));
		return _booking;
	}
 
	@DeleteMapping("/bookings/{id}")
	public ResponseEntity<String> deleteBooking(@PathVariable("id") long id) {
		System.out.println("Delete Booking with ID = " + id + "...");
 
		repository.deleteById(id);
 
		return new ResponseEntity<>("Booking has been deleted!", HttpStatus.OK);
	}
 
	@DeleteMapping("/bookings/delete")
	public ResponseEntity<String> deleteAllBookings() {
		System.out.println("Delete All Booking...");
 
		repository.deleteAll();
 
		return new ResponseEntity<>("All bookings have been deleted!", HttpStatus.OK);
	}
 
	@GetMapping(value = "bookings/cost/{cost}")
	public List<Booking> findByCost(@PathVariable int cost) {
 
		List<Booking> bookings = repository.findByCost(cost);
		return bookings;
	}
 
	@PutMapping("/bookings/{id}")
	public ResponseEntity<Booking> updateBooking(@PathVariable("id") long id, @RequestBody Booking booking) {
		System.out.println("Update Booking with ID = " + id + "...");
 
		Optional<Booking> bookingData = repository.findById(id);
 
		if (bookingData.isPresent()) {
			Booking _booking = bookingData.get();
			_booking.setName(booking.getName());
			_booking.setEmail(booking.getEmail());
			_booking.setAddress(booking.getAddress());
			_booking.setCost(booking.getCost());
			_booking.setActive(booking.isActive());
			
			return new ResponseEntity<>(repository.save(_booking), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

}
