package simu.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import simu.model.Booking;

public interface BookingRepository extends CrudRepository<Booking, Long> {
	
	List<Booking> findByCost(int cost);

}
