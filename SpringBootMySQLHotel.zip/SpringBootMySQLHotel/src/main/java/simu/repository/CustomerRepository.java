package simu.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import simu.model.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
	
	List<Customer> findByAge(int age);
	
	List<Customer> findByCost(int cost);
	
	

}
